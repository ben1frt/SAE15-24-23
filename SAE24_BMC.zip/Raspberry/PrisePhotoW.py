import os
import sys
import TakeAShot



print('Number of arguments:', len(sys.argv), 'arguments.')
print('Argument List:', str(sys.argv))

TakeAShot.PrisePhoto(sys.argv[1], sys.argv[2])

directeur = os.listdir('/dev/video')
L = []
for i in directeur:
    if directeur[i].startswith('video') == True :
        L.append[i]
    print(len(L))
    print(L)