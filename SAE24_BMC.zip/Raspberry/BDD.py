import mysql.connector
import sys

def MaJBDD(projet, nom_image):
        Raspberry = 'localhost'  # adresse ip raspberry
        db = 'bdd'
        User = 'root'
        Password = 'pm925035fd67'
        data_bdd = (projet, nom_image)

        conn = mysql.connector.connect(host=Raspberry,database=db, user=User)

        cursor = conn.cursor()
        cursor.execute( """INSERT INTO TEST (projet, nom_image) VALUES(%s, %s)""", data_bdd)
        conn.commit()

        if conn:
            conn.close()


def MaJMdp():
    Raspberry = 'localhost'  # adresse ip raspberry
    User = 'root'
    Password = 'pm925035fd67'
    db ='bdd'

    conn = mysql.connector.connect(host=Raspberry,database=db, user=User)
    cursor = conn.cursor()

    cursor.execute("""UPDATE TEST SET butoir = butoir - 1 WHERE admin = 0""")
    conn.commit()

    if conn:
        conn.close()

MaJBDD('essaie', 'reussie')
MaJMdp()