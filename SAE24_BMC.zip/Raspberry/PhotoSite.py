import TakeAShot
import os



commande = 'projet=vide | export projet '
